This zip file contains the multimedia materials for "A Queue-Stabilizing Framework for Networked Multi-Robot Exploration" by Lillian Clark, Joseph Galante, Bhaskar Krishnamachari, and Konstantinos Psounis.

The included video accompanies the paper and is compatible with most browsers.
